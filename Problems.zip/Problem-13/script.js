//13- print the sum of two numbers 
function calculateSum(x,y)
{
    var sum = x+y;
    alert("The sum = " + sum);
}

var num1 = window.prompt("Enter num 1 : ");
var num2 = window.prompt("Enter num 2 : ");
calculateSum(num1,num2);

