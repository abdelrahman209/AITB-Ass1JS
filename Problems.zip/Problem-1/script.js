var number = window.prompt("Enter a number");
if(number%2 == 0 )
{
    alert("Even number!");
}
else
{
    alert("Odd number!");
}