function theSumLoop(){
    var sum=0;

    for(var i=1;i<=10;i++)
    {
        sum = sum + i;
    }
    alert(sum + " is the sum from numbers 1 to 10");

}
theSumLoop();